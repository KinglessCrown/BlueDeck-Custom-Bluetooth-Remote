package com.example.btremote

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@SuppressLint("MissingPermission")
@Composable
fun Picker(bt: Bt, store: Store, term: String, setTerm: (String) -> Unit, onClose: () -> Unit) {
    var ble by remember { mutableStateOf(false) }
    var uuid by remember { mutableStateOf(store.charUuid) }
    val found = remember { mutableStateMapOf<String, BluetoothDevice>() }
    DisposableEffect(ble) {
        val stop = if (ble) bt.scan { found[it.address] = it } else ({})
        onDispose { stop() }
    }
    AlertDialog(onDismissRequest = onClose, title = { Text("Connect") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Classic SPP"); Switch(ble, { ble = it }); Text("BLE")
            }
            if (ble) OutlinedTextField(uuid, { uuid = it; store.charUuid = it },
                label = { Text("Write characteristic (blank = auto, e.g. FFE1)") })
            Text("Line ending:")
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("None" to "", "\\n" to "\n", "\\r\\n" to "\r\n").forEach { (n, t) ->
                    FilterChip(term == t, { setTerm(t) }, label = { Text(n) })
                }
            }
            HorizontalDivider()
            val list = if (ble) found.values.toList() else bt.bonded()
            if (!ble && list.isEmpty()) Text("Pair the module in Android settings first.")
            list.forEach { d ->
                TextButton({
                    if (ble) bt.connectBle(d, uuid) else bt.connectSpp(d); onClose()
                }) { Text("${d.name ?: "?"}  ${d.address}") }
            }
        }
    }, confirmButton = { TextButton(onClose) { Text("Close") } },
        dismissButton = { TextButton({ bt.disconnect(); onClose() }) { Text("Disconnect") } })
}
