package com.example.btremote

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** mode: "D" digital (press/release), "T" toggle (on/off), "A" analog slider ({v} in press).
 *  x,y,w,h are in dp, relative to the control area. */
data class Btn(
    val id: Long, val label: String, val mode: String, val press: String,
    val release: String = "", val repeatMs: Int = 0, val min: Int = 0, val max: Int = 100,
    val x: Float = 20f, val y: Float = 20f, val w: Float = 90f, val h: Float = 80f,
    val color: Int = 0xFF3B82F6.toInt()
)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var term: String
        get() = p.getString("term", "\n") ?: "\n"
        set(v) { p.edit().putString("term", v).apply() }
    var charUuid: String
        get() = p.getString("char", "") ?: ""
        set(v) { p.edit().putString("char", v).apply() }

    fun defaults() = listOf(
        Btn(1, "FORWARD", "D", "E1", "E0", x = 110f, y = 10f),
        Btn(2, "BACK", "D", "E2", "E0", x = 110f, y = 190f),
        Btn(3, "LEFT", "D", "E3", "E0", x = 10f, y = 100f),
        Btn(4, "RIGHT", "D", "E4", "E0", x = 210f, y = 100f),
        Btn(5, "SPEED", "A", "E1.{v}", "", 0, 0, 100, x = 340f, y = 110f, w = 300f, h = 70f, color = 0xFFF59E0B.toInt()),
    )

    fun load(): List<Btn> {
        val s = p.getString("btns", null) ?: return defaults()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Btn(o.getLong("id"), o.getString("label"), o.getString("mode"), o.getString("press"),
                    o.getString("release"), o.getInt("rep"), o.getInt("min"), o.getInt("max"),
                    o.optDouble("x", 20.0 + (i % 3) * 100).toFloat(), o.optDouble("y", 20.0 + (i / 3) * 90).toFloat(),
                    o.optDouble("w", 90.0).toFloat(), o.optDouble("h", 80.0).toFloat(),
                    o.optInt("color", 0xFF3B82F6.toInt()))
            }
        } catch (e: Exception) { defaults() }
    }

    fun save(list: List<Btn>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("label", it.label).put("mode", it.mode)
                .put("press", it.press).put("release", it.release).put("rep", it.repeatMs)
                .put("min", it.min).put("max", it.max).put("x", it.x.toDouble()).put("y", it.y.toDouble())
                .put("w", it.w.toDouble()).put("h", it.h.toDouble()).put("color", it.color))
        }
        p.edit().putString("btns", a.toString()).apply()
    }
}
