package com.example.btremote

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import java.io.OutputStream
import java.util.UUID

@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class Bt(private val ctx: Context, private val onState: (String) -> Unit) {
    private val adapter: BluetoothAdapter =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var sock: BluetoothSocket? = null
    private var out: OutputStream? = null
    private var gatt: BluetoothGatt? = null
    private var chr: BluetoothGattCharacteristic? = null

    fun bonded(): List<BluetoothDevice> = try { adapter.bondedDevices.toList() } catch (e: Exception) { emptyList() }

    /** Returns a stop function. */
    fun scan(onFound: (BluetoothDevice) -> Unit): () -> Unit {
        val s = adapter.bluetoothLeScanner ?: return {}
        val cb = object : ScanCallback() {
            override fun onScanResult(t: Int, r: ScanResult) = onFound(r.device)
        }
        s.startScan(cb)
        return { try { s.stopScan(cb) } catch (_: Exception) {} }
    }

    fun connectSpp(d: BluetoothDevice) {
        disconnect(); onState("Connecting…")
        Thread {
            try {
                val s = d.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                adapter.cancelDiscovery(); s.connect()
                sock = s; out = s.outputStream; onState("Connected (SPP): ${d.name}")
            } catch (e: Exception) { onState("Failed: ${e.message}") }
        }.start()
    }

    /** charUuid: blank = first writable characteristic; or full/short UUID like FFE1 */
    fun connectBle(d: BluetoothDevice, charUuid: String) {
        disconnect(); onState("Connecting…")
        gatt = d.connectGatt(ctx, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, st: Int, ns: Int) {
                if (ns == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
                else { chr = null; onState("Disconnected") }
            }
            override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
                val w = BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE
                chr = g.services.flatMap { it.characteristics }.firstOrNull {
                    if (charUuid.isNotBlank()) it.uuid.toString().contains(charUuid.trim(), true)
                    else it.properties and w != 0
                }
                onState(if (chr != null) "Connected (BLE): ${d.name} [${chr!!.uuid.toString().take(8)}]"
                        else "No writable characteristic found")
            }
        }, BluetoothDevice.TRANSPORT_LE)
    }

    fun send(data: ByteArray) {
        if (data.isEmpty()) return
        try {
            out?.let { it.write(data); it.flush() }
            val c = chr; val g = gatt
            if (c != null && g != null) {
                data.toList().chunked(20).forEach { part ->
                    c.writeType = if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
                        BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                    c.value = part.toByteArray()
                    g.writeCharacteristic(c)
                }
            }
        } catch (e: Exception) { onState("Send error: ${e.message}") }
    }

    fun disconnect() {
        try { sock?.close() } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        sock = null; out = null; gatt = null; chr = null
    }
}
