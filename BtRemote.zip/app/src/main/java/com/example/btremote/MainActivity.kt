package com.example.btremote

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val perms = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}.launch(perms)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { App(this) } } }
    }
}

/** Text is sent + line ending. Prefix "hex:" for raw bytes, e.g. "hex:E1 0A". {v} = analog value. */
fun encode(s: String, v: Int?, term: String): ByteArray {
    val t = if (v != null) s.replace("{v}", v.toString()) else s
    if (t.isBlank()) return ByteArray(0)
    if (t.startsWith("hex:")) return try {
        t.substring(4).split(Regex("[\\s,]+")).filter { it.isNotBlank() }
            .map { it.removePrefix("0x").toInt(16).toByte() }.toByteArray()
    } catch (e: Exception) { ByteArray(0) }
    return (t + term).toByteArray()
}

val PALETTE = listOf(0xFF3B82F6, 0xFF22C55E, 0xFFEF4444, 0xFFF59E0B, 0xFFA855F7, 0xFF64748B).map { it.toInt() }
fun snap(v: Float) = Math.round(v / 4f) * 4f

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx) }
    val btns = remember { mutableStateListOf<Btn>().apply { addAll(store.load()) } }
    var status by remember { mutableStateOf("Not connected") }
    val bt = remember { Bt(ctx) { status = it } }
    var edit by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Btn?>(null) }
    var picker by remember { mutableStateOf(false) }
    var term by remember { mutableStateOf(store.term) }

    val send: (String, Int?) -> Unit = { s, v -> bt.send(encode(s, v, term)) }
    fun save() = store.save(btns.toList())
    fun upd(n: Btn) { val i = btns.indexOfFirst { it.id == n.id }; if (i >= 0) btns[i] = n }
    fun settle(id: Long) {
        btns.firstOrNull { it.id == id }?.let { upd(it.copy(x = snap(it.x), y = snap(it.y), w = snap(it.w), h = snap(it.h))) }
        save()
    }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(status, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            if (edit) {
                TextButton({ btns.clear(); btns.addAll(store.defaults()); save() }) { Text("Reset") }
                TextButton({ editing = Btn(System.currentTimeMillis(), "NEW", "D", "") }) { Text("+ Add") }
            }
            Text("Edit"); Switch(edit, { edit = it; if (!it) save() })
            Button({ picker = true }) { Text("Connect") }
        }
        Box(Modifier.fillMaxSize().then(if (edit) Modifier.border(1.dp, Color.Gray) else Modifier)) {
            btns.forEach { b ->
                key(b.id) {
                    BtnView(b, edit, send, onTap = { editing = b }, onChange = ::upd, onDone = { settle(b.id) })
                }
            }
        }
    }

    editing?.let { cur ->
        Editor(cur, onSave = { n ->
            if (btns.any { it.id == n.id }) upd(n) else btns.add(n)
            save(); editing = null
        }, onDuplicate = { n ->
            btns.add(n.copy(id = System.currentTimeMillis(), x = n.x + 20, y = n.y + 20)); save(); editing = null
        }, onDelete = { btns.removeAll { it.id == cur.id }; save(); editing = null }, onClose = { editing = null })
    }
    if (picker) Picker(bt, store, term, { term = it; store.term = it }) { picker = false }
}

@Composable
fun BtnView(b: Btn, edit: Boolean, send: (String, Int?) -> Unit,
            onTap: () -> Unit, onChange: (Btn) -> Unit, onDone: () -> Unit) {
    val cur by rememberUpdatedState(b)
    val dens = LocalDensity.current.density
    val scope = rememberCoroutineScope()
    var on by remember { mutableStateOf(false) }
    val base = Color(b.color)
    val bg = when (b.mode) { "T" -> if (on) base else base.copy(alpha = 0.45f); "J" -> base.copy(alpha = 0.3f); else -> base }

    Box(
        Modifier.offset(b.x.dp, b.y.dp).size(b.w.dp, b.h.dp).clip(RoundedCornerShape(16.dp))
            .background(bg)
            .then(if (!edit && b.mode != "A" && b.mode != "J") Modifier.pointerInput(b.id) {
                detectTapGestures(onPress = {
                    val c = cur
                    if (c.mode == "T") {
                        on = !on; send(if (on) c.press else c.release, null)
                    } else {
                        send(c.press, null)
                        val job = if (c.repeatMs > 0) scope.launch {
                            while (true) { delay(c.repeatMs.toLong()); send(c.press, null) }
                        } else null
                        tryAwaitRelease(); job?.cancel()
                        if (c.release.isNotBlank()) send(c.release, null)
                    }
                })
            } else Modifier),
        contentAlignment = Alignment.Center
    ) {
        when (b.mode) {
            "A" -> AnalogCtl(b, send)
            "J" -> Stick(b, send)
            else -> Text(b.label, color = Color.White, fontWeight = FontWeight.Bold)
        }

        if (edit) {
            // drag = move, tap = edit
            Box(Modifier.matchParentSize().border(2.dp, Color.White, RoundedCornerShape(16.dp))
                .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) }
                .pointerInput(Unit) {
                    detectDragGestures(onDragEnd = { onDone() }) { c, d ->
                        c.consume(); onChange(cur.copy(x = max(0f, cur.x + d.x / dens), y = max(0f, cur.y + d.y / dens)))
                    }
                })
            // resize handle
            Box(Modifier.align(Alignment.BottomEnd).size(36.dp).background(Color.White.copy(alpha = 0.7f), CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures(onDragEnd = { onDone() }) { c, d ->
                        c.consume(); onChange(cur.copy(w = max(48f, cur.w + d.x / dens), h = max(40f, cur.h + d.y / dens)))
                    }
                })
        }
    }
}

@Composable
fun AnalogCtl(b: Btn, send: (String, Int?) -> Unit) {
    var v by remember { mutableFloatStateOf(b.min.toFloat()) }
    var last by remember { mutableIntStateOf(Int.MIN_VALUE) }
    var lastT by remember { mutableLongStateOf(0L) }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.Center) {
        Text("${b.label}: ${v.toInt()}", color = Color.White, fontWeight = FontWeight.Bold)
        Slider(v, { nv ->
            v = nv; val i = nv.toInt(); val now = System.currentTimeMillis()
            if (i != last && now - lastT > 40) { last = i; lastT = now; send(b.press, i) }
        }, valueRange = b.min.toFloat()..max(b.max, b.min + 1).toFloat(),
            onValueChangeFinished = { send(b.press, v.toInt()); if (b.release.isNotBlank()) send(b.release, v.toInt()) },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White))
    }
}

@Composable
fun Editor(b: Btn, onSave: (Btn) -> Unit, onDuplicate: (Btn) -> Unit, onDelete: () -> Unit, onClose: () -> Unit) {
    var label by remember { mutableStateOf(b.label) }
    var mode by remember { mutableStateOf(b.mode) }
    var press by remember { mutableStateOf(b.press) }
    var release by remember { mutableStateOf(b.release) }
    var rep by remember { mutableStateOf(b.repeatMs.toString()) }
    var min by remember { mutableStateOf(b.min.toString()) }
    var max by remember { mutableStateOf(b.max.toString()) }
    var color by remember { mutableIntStateOf(b.color) }
    fun build() = b.copy(label = label, mode = mode, press = press, release = release,
        repeatMs = rep.toIntOrNull() ?: 0, min = min.toIntOrNull() ?: 0, max = max.toIntOrNull() ?: 100, color = color)

    AlertDialog(onDismissRequest = onClose, title = { Text("Edit button") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("D" to "Hold", "T" to "Toggle", "A" to "Slider", "J" to "Stick").forEach { (m, n) ->
                    FilterChip(mode == m, {
                        mode = m
                        if (m == "J" && min == "0" && max == "100") min = "-100"
                        if (m != "J" && min == "-100") min = "0"
                    }, label = { Text(n) })
                }
            }
            OutlinedTextField(label, { label = it }, label = { Text("Label") }, singleLine = true)
            OutlinedTextField(press, { press = it }, singleLine = true, label = {
                Text(when (mode) { "A" -> "Sends, e.g. E1.{v}"; "J" -> "Sends, e.g. J{x},{y}"; "T" -> "Sends when ON"; else -> "Sends on press, e.g. E1" })
            })
            OutlinedTextField(release, { release = it }, singleLine = true, label = {
                Text(if (mode == "T") "Sends when OFF" else "Sends on release (optional)")
            })
            when (mode) {
                "A", "J" -> { OutlinedTextField(min, { min = it }, label = { Text("Min") }, singleLine = true)
                         OutlinedTextField(max, { max = it }, label = { Text("Max") }, singleLine = true) }
                "D" -> OutlinedTextField(rep, { rep = it }, label = { Text("Repeat while held (ms, 0 = off)") }, singleLine = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PALETTE.forEach { c ->
                    Box(Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                        .border(if (c == color) 3.dp else 0.dp, Color.White, CircleShape).clickable { color = c })
                }
            }
            Text("Stick: {x} and {y} are replaced with values from Min to Max (centre = middle). Release sends the centre values, then the release command.", style = MaterialTheme.typography.bodySmall)
            Text("Raw bytes: start with hex: e.g. hex:E1 0A", style = MaterialTheme.typography.bodySmall)
            Text("Drag a button to move it. Drag its corner dot to resize.", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton({ onSave(build()) }) { Text("Save") } },
        dismissButton = {
            Row {
                TextButton(onDelete) { Text("Delete") }
                TextButton({ onDuplicate(build()) }) { Text("Copy") }
                TextButton(onClose) { Text("Cancel") }
            }
        })
}

@Composable
fun Stick(b: Btn, send: (String, Int?) -> Unit) {
    var kx by remember { mutableFloatStateOf(0f) }   // -1..1, right positive
    var ky by remember { mutableFloatStateOf(0f) }   // -1..1, down positive
    var last by remember { mutableStateOf("") }
    var lastT by remember { mutableLongStateOf(0L) }
    val cur by rememberUpdatedState(b)

    fun fill(t: String): String {
        val c = cur
        val mid = (c.min + c.max) / 2f; val half = (c.max - c.min) / 2f
        return t.replace("{x}", Math.round(mid + kx * half).toString())
            .replace("{y}", Math.round(mid - ky * half).toString())   // up = max
    }
    fun out(force: Boolean) {
        val s = fill(cur.press); val now = System.currentTimeMillis()
        if (s != last && (force || now - lastT > 50)) { last = s; lastT = now; send(s, null) }
    }

    Canvas(Modifier.fillMaxSize().pointerInput(Unit) {
        val reach = minOf(size.width, size.height) / 2f * 0.65f
        fun move(p: Offset) {
            var dx = p.x - size.width / 2f; var dy = p.y - size.height / 2f
            val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (len > reach) { dx *= reach / len; dy *= reach / len }
            kx = dx / reach; ky = dy / reach; out(false)
        }
        fun stop() {
            kx = 0f; ky = 0f; out(true)
            if (cur.release.isNotBlank()) send(fill(cur.release), null)
        }
        detectDragGestures(onDragStart = { move(it) }, onDragEnd = { stop() }, onDragCancel = { stop() }) { c, _ ->
            c.consume(); move(c.position)
        }
    }) {
        val r = minOf(size.width, size.height) / 2f
        drawCircle(Color.White.copy(alpha = 0.15f), r * 0.98f, center)
        drawCircle(Color.White.copy(alpha = 0.5f), r * 0.65f, center, style = Stroke(2.dp.toPx()))
        drawCircle(Color.White, r * 0.3f, Offset(center.x + kx * r * 0.65f, center.y + ky * r * 0.65f))
    }
}
